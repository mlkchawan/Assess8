package com.infinite.model;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EmpId")
	private int empid;
	@Column(name = "firstName")
	private String Firstname;
	@Column(name = "LastName")
	private String lastname;
	@Column(name = "Department")
	private String department;
	
	
	public Employee() {
		//super();
	}
	
	public Employee(int empid, String firstname, String lastname, String department) {
	//	super();
		this.empid = empid;
		Firstname = firstname;
		this.lastname = lastname;
		this.department = department;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
}
